//
//  BaseViewController.swift
//  SwiftDemo
//
//  Created by 杨建祥 on 2020/4/13.
//

import UIKit

open class BaseViewController: UIViewController {
    
    open override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .white
    }

}
