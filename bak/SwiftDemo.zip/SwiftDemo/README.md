# SwiftDemo

[![CI Status](https://img.shields.io/travis/tospery/SwiftDemo.svg?style=flat)](https://travis-ci.org/tospery/SwiftDemo)
[![Version](https://img.shields.io/cocoapods/v/SwiftDemo.svg?style=flat)](https://cocoapods.org/pods/SwiftDemo)
[![License](https://img.shields.io/cocoapods/l/SwiftDemo.svg?style=flat)](https://cocoapods.org/pods/SwiftDemo)
[![Platform](https://img.shields.io/cocoapods/p/SwiftDemo.svg?style=flat)](https://cocoapods.org/pods/SwiftDemo)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

SwiftDemo is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'SwiftDemo'
```

## Author

tospery, yangjianxiang@cd.tuan800.com

## License

SwiftDemo is available under the MIT license. See the LICENSE file for more info.
