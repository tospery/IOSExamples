//
//  Button.swift
//  Pods
//
//  Created by 杨建祥 on 2020/2/1.
//

import UIKit
import QMUIKit

public class Button: QMUIButton {

}
