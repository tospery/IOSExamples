//
//  CollectionViewReactor.swift
//  SwiftFrame
//
//  Created by 杨建祥 on 2020/4/7.
//

import UIKit

open class CollectionViewReactor: ScrollViewReactor {

}
