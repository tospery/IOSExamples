//
//  BaseCollectionItem.swift
//  SwiftFrame
//
//  Created by 杨建祥 on 2020/4/10.
//

import UIKit

open class BaseCollectionItem: BaseItem {
    
}
