//
//  HomeViewController+Share.swift
//  IOSExamples
//
//  Created by 杨建祥 on 2022/11/21.
//

import UIKit
import Rswift

extension HomeViewController {
    
    @objc func shareNative(_ parameters: [String: Any]?) {
//        // let text = "分享内容的标题"
//        let title = "分享内容的标题"
//        let message = "这是具体分享的内容，比如活动截止到本月底，大家快快来参加吧~"
//        let image = R.image.share_bg()!
//        let url = "https://github.com/tospery/flutter_hub".url!
//        let vc = UIActivityViewController(activityItems: [title, image, message, url], applicationActivities: nil)
//        vc.completionWithItemsHandler = { (type,completed,items,error) in
//            print("completionWithItemsHandler. type=\(String(describing: type)) completed=\(completed) items=\(items) error=\(error)")
//        }
//        self.present(vc, animated: true, completion: nil)
        
//        let vc = UIActivityViewController(
//            activityItems: [
//                "分享内容的标题",
//                URL(string: "https://github.com/tospery/flutter_hub")!
//            ],
//            applicationActivities: nil
//        )
//        self.present(vc, animated: true, completion: nil)
        // UIApplication.shared.keyWindow!.rootViewController?.present(vc, animated: true, completion: nil)
    }

}
