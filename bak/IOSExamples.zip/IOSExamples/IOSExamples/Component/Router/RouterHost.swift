//
//  RouterHost.swift
//  IOSExamples
//
//  Created by liaoya on 2021/6/28.
//

import Foundation
import HiIOS

extension Router.Host {
    static var about: Router.Host { "about" }
}
