//
//  Appearance+Ex.swift
//  IOSExamples
//
//  Created by liaoya on 2022/2/15.
//

import Foundation
import HiIOS

extension Appearance: AppearanceCompatible {
    
    public func myConfig() {
        self.basic()
    }
    
}
