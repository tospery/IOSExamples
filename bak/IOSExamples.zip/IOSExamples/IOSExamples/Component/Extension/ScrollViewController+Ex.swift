//
//  ScrollViewController+Ex.swift
//  IOSExamples
//
//  Created by liaoya on 2021/6/28.
//

import UIKit
import HiIOS

extension ScrollViewController {
    
    @objc func mySetupRefresh(should: Bool) {
        self.mySetupRefresh(should: should)
    }
    
    @objc func mySetupLoadMore(should: Bool) {
        self.mySetupLoadMore(should: should)
    }
    
}
