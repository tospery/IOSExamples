//
//  Simple+Ex.swift
//  IOSExamples
//
//  Created by 杨建祥 on 2022/10/3.
//

import Foundation
import HiIOS

extension Simple {
    
    enum Identifier: Int, Codable {
        case userType = 1
        case userName
        case userEmail
    }
    
}
