//
//  PayManager.swift
//  IOSExamples
//
//  Created by liaoya on 2021/6/28.
//

import Foundation

class PayManager: NSObject {

    static let shared = PayManager()

    override init() {
        super.init()
    }

}
