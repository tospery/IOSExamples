//
//  OCHelper.h
//  IOSExamples
//
//  Created by 杨建祥 on 2020/11/28.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface OCHelper : NSObject

+ (instancetype)sharedInstance;

@end

NS_ASSUME_NONNULL_END
